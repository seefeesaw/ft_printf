/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_numlen_umax.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:53:38 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:53:40 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
** Returns the length of a number, with an additional space for the '-' for
** negative numbers.
*/

#include "libft.h"

int		ft_numlen_umax(uintmax_t nb, int base)
{
	int	len;

	if (base < 2)
		return (0);
	len = 1;
	while ((nb /= base))
		len++;
	return (len);
}
