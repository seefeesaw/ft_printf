/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_numlen_max.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:53:06 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:53:09 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
** Returns the length of a number, with an additional space for the '-' for
** negative numbers.
*/

#include "libft.h"

int		ft_numlen_max(intmax_t nb, int base)
{
	int	len;

	if (base < 2)
		return (0);
	len = (nb < 0) ? 2 : 1;
	while ((nb /= base))
		len++;
	return (len);
}
