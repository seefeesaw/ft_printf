/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 13:55:41 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 15:55:41 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include "../libft/libft.h"
# include <limits.h>
# include <locale.h>

# define BUFFSIZE 20
# define SPECIFIERS "sSpdDioOuUxXcCb%"
# define VALID_CHARS "sSpdDioOuUxXcCb%lhjz-+0123456789. #"
# define SP_LEN (ft_strlen(SPECIFIERS))

typedef struct	s_printf
{
	int		is_zero;
	int		is_space;
	int		is_hash;
	int		is_minus;
	int		is_plus;

	int		width;
	int		precision;

	int		is_hh;
	int		is_h;
	int		is_ll;
	int		is_l;
	int		is_j;
	int		is_z;
	char	converter;
	int		negative;

}				t_printf;

char			*parse_spec(char *s, t_printf *spec);
int				ft_printf(char *format, ...);
char			*convert_s(char *str, t_printf *spec);
char			*convert_d(va_list ap, t_printf *spec);
char			*convert_u(va_list ap, t_printf *spec);
char			*convert_x(va_list ap, t_printf *spec);
char			*convert_o(va_list ap, t_printf *spec);
char			*convert_c(va_list ap, t_printf *spec);
char			*convert_p(va_list ap, t_printf *spec);
char			*padding(char *str, t_printf *spec);
char			*handle_unicode(wchar_t chr);
char			*wstring(wchar_t *str);
char			*init_d(va_list ap, t_printf *spec);
char			*init_s(va_list ap, t_printf *spec);
char			*handle_percent(t_printf *spec);
int				empty_string(t_printf *spec, int count);
char			*get_len(char *str, t_printf *spec);
char			*get_flags(char *str, t_printf *spec);

#endif
