/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 14:05:16 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 15:46:09 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

#include <wchar.h>

static int		print_string(char *str)
{
	int c;

	c = 0;
	c += ft_putstr(str);
	free(str);
	return (c);
}

static int		print_arg(va_list ap, t_printf *spec, char *s, int count)
{
	if (spec->converter == '%')
		s = handle_percent(spec);
	else if (spec->converter == 'p')
		s = convert_p(ap, spec);
	else if (spec->converter == 'x' || spec->converter == 'X')
		s = convert_x(ap, spec);
	else if (spec->converter == 'o' || spec->converter == 'O')
		s = convert_o(ap, spec);
	else if (spec->converter == 'd' || spec->converter == 'i')
		s = convert_d(ap, spec);
	else if (spec->converter == 'D')
		s = init_d(ap, spec);
	else if (spec->converter == 'u' || spec->converter == 'U')
		s = convert_u(ap, spec);
	else if (spec->converter == 'c' || spec->converter == 'C')
	{
		s = convert_c(ap, spec);
		if (s == NULL)
			return (empty_string(spec, count));
	}
	else if (spec->converter == 's' || spec->converter == 'S')
		s = init_s(ap, spec);
	else if (spec->converter)
		s = init_s(ap, spec);
	return (print_string(s));
}

static int		parse_format(va_list ap, char **format)
{
	t_printf	new_lst;

	ft_memset(&new_lst, 0, sizeof(t_printf));
	new_lst.converter = 0;
	*format = parse_spec(*format, &new_lst);
	return (print_arg(ap, &new_lst, NULL, 0));
}

int				ft_printf(char *format, ...)
{
	va_list		ap;
	int			ctrl;
	int			rt;
	char		*temp;

	va_start(ap, format);
	rt = 0;
	ctrl = 0;
	temp = ft_strnew(BUFFSIZE);
	while (*format)
	{
		while (ctrl < BUFFSIZE && *format && *format != '%' && ++rt)
			temp[ctrl++] = *(format++);
		if (ctrl)
			write(1, temp, ctrl);
		ft_bzero((void*)temp, ctrl);
		ctrl = 0;
		if (*format == '%')
			rt += (parse_format(ap, &format));
	}
	if (ctrl)
		write(1, temp, ctrl);
	free(temp);
	va_end(ap);
	return (rt);
}

size_t			ft_wchar_len(wchar_t c)
{
	if ((int)c >= 0 && (int)c <= 0x7F)
		return (1);
	else if ((int)c <= 0x7FF)
		return (2);
	else if ((int)c <= 0xFFFF)
		return (3);
	else if ((int)c <= 0x10FFFF)
		return (4);
	return (0);
}
