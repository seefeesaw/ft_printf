/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unicode_convert.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 14:37:14 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 17:12:25 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

char			*handle_unicode(wchar_t chr)
{
	char	*s;

	if (!(s = ft_strnew(4)))
		return (NULL);
	if (chr <= 0x7F)
		s[0] = chr;
	else if (chr <= 0x7FF)
	{
		s[0] = (chr >> 6) + 0xC0;
		s[1] = (chr & 0x3F) + 0x80;
	}
	else if (chr < 0xFFFF)
	{
		s[0] = (chr >> 12) + 0xE0;
		s[1] = ((chr >> 6) & 0x3F) + 0x80;
		s[2] = (chr & 0x3F) + 0x80;
	}
	else
	{
		s[0] = ((chr >> 18) + 0xF0);
		s[1] = ((chr >> 12) & 0x3F) + 0x80;
		s[2] = ((chr >> 6) & 0x3F) + 0x80;
		s[3] = (chr & 0x3F) + 0x80;
	}
	return (s);
}

char			*wstring(wchar_t *str)
{
	char	*rt;

	if (!str || (!(rt = ft_strnew(1))))
		return (NULL);
	while (*str)
	{
		rt = ft_strjoinfree(rt, handle_unicode(*str), 3);
		str++;
	}
	return (rt);
}

static void		truncate_wstr(char *s, t_printf *spec)
{
	if ((spec->converter == 'S' || spec->is_l == 1) && spec->precision)
	{
		while ((spec->converter == 'S' || spec->is_l == 1) &&
				(*(s + spec->precision) & 0xC0) == 0x80)
			spec->precision -= 1;
		ft_strclr(s + spec->precision);
	}
}

char			*convert_s(char *str, t_printf *spec)
{
	char	*temp;
	int		len;

	if ((int)ft_strlen(str) > spec->precision && spec->precision > 0)
		truncate_wstr(str, spec);
	if (spec->precision == 0)
		str = ft_strdup("");
	else if (spec->precision > 0 && spec->precision < (int)ft_strlen(str))
		str = ft_strndup(str, spec->precision);
	if (spec->width > 0 && spec->width > (int)ft_strlen(str))
	{
		len = spec->width - ft_strlen(str);
		len = (spec->negative) ? (len - 1) : (len);
		temp = ft_strnew(len);
		temp = ft_memset((void*)temp, (spec->is_zero &&
					!spec->is_minus) ? '0' : ' ', len);
		if (spec->is_minus)
			str = ft_strjoinfree(str, temp, 3);
		else
			str = ft_strjoinfree(temp, str, 3);
	}
	return (str);
}
