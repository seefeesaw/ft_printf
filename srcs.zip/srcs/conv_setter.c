/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conv_setter.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 15:17:12 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 15:42:21 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

char		*init_d(va_list ap, t_printf *spec)
{
	char	*s;

	if (spec->converter == 'D')
	{
		spec->is_l = 1;
		spec->is_h = 0;
		spec->is_hh = 0;
	}
	s = convert_d(ap, spec);
	return (s);
}

char		*init_s(va_list ap, t_printf *spec)
{
	char	*s;

	if (!ft_strchr(SPECIFIERS, spec->converter))
	{
		if (spec->width >= 0)
			spec->precision = -1;
		s = ft_strdup(&(spec->converter));
	}
	else if (spec->converter == 'S' || spec->is_l)
		s = wstring(va_arg(ap, wchar_t*));
	else
		s = ft_strdup(va_arg(ap, char*));
	if (!s)
		s = ft_strdup("(null)");
	s = convert_s(s, spec);
	return (s);
}

char		*handle_percent(t_printf *spec)
{
	spec->precision = -1;
	spec->is_plus = 0;
	return (padding(ft_strdup("%\0"), spec));
}

int			empty_string(t_printf *spec, int count)
{
	char	*s;

	spec->precision = 0;
	spec->width--;
	s = padding(ft_strdup(""), spec);
	if (spec->is_minus)
	{
		ft_putchar('\0');
		count += ft_putstr(s);
		return (count + 1);
	}
	count += ft_putstr(s);
	ft_putchar('\0');
	return (count + 1);
}
