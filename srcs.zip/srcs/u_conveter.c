/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   u_conveter.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 15:21:32 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 17:19:59 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static long long		convert_len(va_list ap, const t_printf *spec)
{
	if (spec->is_ll == 1)
		return ((unsigned long long)va_arg(ap, long long));
	if (spec->is_l == 1 || spec->converter == 'U' ||
			spec->converter == 'O')
		return ((unsigned long)va_arg(ap, long));
	if (spec->is_hh == 1)
		return ((unsigned char)va_arg(ap, int));
	if (spec->is_h == 1)
		return ((unsigned short)va_arg(ap, int));
	if (spec->is_j == 1)
		return ((uintmax_t)va_arg(ap, uintmax_t));
	if (spec->is_z)
		return ((size_t)va_arg(ap, size_t));
	return ((unsigned int)va_arg(ap, int));
}

char					*convert_u(va_list ap, t_printf *spec)
{
	long long		n;
	char			*rt;

	n = convert_len(ap, spec);
	spec->negative = 0;
	spec->is_plus = 0;
	rt = ft_itoa_base_u(n, 10);
	if (spec->precision == 0 && n == 0)
		rt = ft_strdup("");
	if (spec->precision > -1 && spec->width > -1)
		spec->is_zero = 0;
	rt = padding(rt, spec);
	return (rt);
}

static char				*handle_hash(char *rt, t_printf *spec)
{
	if (!spec->is_zero && spec->precision == -1)
		return (ft_strjoinfree("0X", rt, 2));
	else
	{
		if (spec->width != -1 || spec->precision != -1)
		{
			if ((int)ft_strlen(rt) > spec->precision)
			{
				rt = ft_strjoinfree("0X", rt, 2);
				return (padding(rt, spec));
			}
			spec->width -= 2;
			rt = padding(rt, spec);
		}
		return (ft_strjoinfree("0X", rt, 2));
	}
	return (rt);
}

char					*convert_x(va_list ap, t_printf *spec)
{
	long long	n;
	char		*rt;

	n = convert_len(ap, spec);
	spec->negative = 0;
	spec->is_plus = 0;
	if (spec->precision >= 0)
		spec->is_zero = 0;
	rt = ft_itoa_base_u(n, 16);
	if (spec->is_hash && n != 0)
		rt = handle_hash(rt, spec);
	if (spec->precision == 0 && n == 0)
	{
		free(rt);
		rt = ft_strdup("");
	}
	rt = padding(rt, spec);
	if (spec->is_hash && rt[1] == '0' && ft_strchr(rt, 'X'))
	{
		*(ft_strchr(rt, 'X')) = '0';
		rt[1] = 'X';
	}
	if (spec->converter == 'x')
		return (ft_strmap_p(rt, ft_tolowercase));
	return (rt);
}

char					*convert_o(va_list ap, t_printf *spec)
{
	long long	n;
	char		*rt;

	spec->is_plus = 0;
	spec->negative = 0;
	n = convert_len(ap, spec);
	rt = ft_itoa_base_u(n, 8);
	if (spec->precision > -1 && spec->width > -1)
		spec->is_zero = 0;
	if (spec->precision == 0 && !spec->is_hash && n == 0)
	{
		free(rt);
		rt = ft_strdup("");
	}
	if ((spec->converter == 'o' || spec->converter == 'O')
			&& (spec->is_hash && n != 0))
		rt = ft_strjoinfree("0", rt, 2);
	rt = (padding(rt, spec));
	return (rt);
}
