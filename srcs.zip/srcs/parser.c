/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 15:10:28 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 15:16:10 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static char	*find_specifier(char *s, t_printf *spec)
{
	while (*(++s))
	{
		if ((ft_strchr(SPECIFIERS, *s)))
			return (s);
		if (!(ft_strchr(VALID_CHARS, *s)))
		{
			spec->converter = '0';
			return (s);
		}
	}
	return (NULL);
}

static int	get_width(t_printf *spec, char *spec_pos)
{
	char	*pos;

	pos = spec_pos;
	while (*(--pos) != '%')
	{
		if (ft_isdigit(*pos) && (!(ft_isdigit(*(pos - 1))))
				&& *(pos - 1) != '.')
		{
			spec->width = ft_atoi(pos);
			return (1);
		}
	}
	return (0);
}

static int	get_precision(t_printf *spec, char *spec_pos)
{
	char	*pos;

	pos = spec_pos;
	while (*(--pos) != '%')
	{
		if (*pos == '.')
		{
			spec->precision = ft_atoi(pos + 1);
			return (1);
		}
	}
	return (0);
}

char		*parse_spec(char *s, t_printf *spec)
{
	char		*pos;
	char		*str;
	char		*temp;

	pos = NULL;
	if (!(pos = find_specifier(s, spec)))
		return (s + 1);
	while ((ft_strchr(VALID_CHARS, *pos)) && !ft_strchr(SPECIFIERS, *pos))
		pos++;
	if (ft_strchr(SPECIFIERS, *pos))
		spec->converter = *pos;
	else
		spec->converter = *pos;
	str = ft_strndup(s, pos + 1 - s);
	temp = str;
	str = get_flags(str, spec);
	if (!(get_width(spec, pos)))
		spec->width = -1;
	if (!(get_precision(spec, pos)))
		spec->precision = -1;
	str = get_len(str, spec);
	free(temp);
	if (spec->converter == '0')
		return (pos);
	return (pos + 1);
}
