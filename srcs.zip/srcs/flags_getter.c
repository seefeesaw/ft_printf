/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   flags_getter.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 14:50:26 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 14:55:44 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static char	*set_len(char *fstr, int *len_conv, int offset)
{
	*len_conv = 1;
	return (fstr += offset);
}

char		*get_len(char *str, t_printf *spec)
{
	if (!str)
		return (str);
	if (ft_strstr(str, "ll") && (spec->is_ll = 1))
		return (str + 2);
	else if (ft_strstr(str, "hh") && (spec->is_hh = 1))
		return (str + 2);
	else if (ft_strstr(str, "l"))
		return (set_len(str, &spec->is_l, 1));
	else if (ft_strstr(str, "h"))
		return (set_len(str, &spec->is_h, 1));
	else if (ft_strstr(str, "j"))
		return (set_len(str, &spec->is_j, 1));
	else if (ft_strstr(str, "z"))
		return (set_len(str, &spec->is_z, 1));
	else
		return (str);
}

char		*get_flags(char *str, t_printf *new)
{
	while (*(++str))
	{
		if (*str == '#')
			new->is_hash = 1;
		else if (*str == '0')
			new->is_zero = 1;
		else if (*str == '-')
			new->is_minus = 1;
		else if (*str == ' ')
			new->is_space = 1;
		else if (*str == '+')
			new->is_plus = 1;
		else
			return (str);
	}
	return (str);
}
