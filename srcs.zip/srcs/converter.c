/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   converter.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 14:38:45 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 17:16:43 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

char			*convert_c(va_list ap, t_printf *spec)
{
	wchar_t	chr;
	char	*rt;

	if (spec->converter == 'C' || spec->is_l)
	{
		chr = va_arg(ap, wchar_t);
		rt = handle_unicode(chr);
		spec->is_l = 1;
		spec->precision = -1;
	}
	else
	{
		chr = va_arg(ap, int);
		rt = ft_strnew(1);
		spec->precision = -1;
		rt[0] = chr;
	}
	if (chr == 0)
		rt = NULL;
	rt = padding(rt, spec);
	return (rt);
}

static intmax_t	convert_len(va_list ap, t_printf *spec)
{
	intmax_t	n;

	if (spec->is_hh == 1)
		n = (signed char)(va_arg(ap, int));
	else if (spec->is_h == 1)
		n = (short)(va_arg(ap, int));
	else if (spec->is_ll == 1)
		n = (long long)(va_arg(ap, long long int));
	else if (spec->is_l == 1)
		n = (long)(va_arg(ap, long));
	else if (spec->is_j == 1)
		n = (intmax_t)(va_arg(ap, intmax_t));
	else if (spec->is_z == 1)
		n = (size_t)(va_arg(ap, size_t));
	else
		n = (int)(va_arg(ap, int));
	n = (intmax_t)n;
	return (n);
}

static char		*p_padding(char *rt, t_printf *spec)
{
	if (spec->is_zero)
	{
		spec->width -= 2;
		rt = padding(rt, spec);
		rt = ft_strjoinfree("0x", rt, 2);
	}
	else if (spec->width == -1 || spec->precision > spec->width)
	{
		rt = padding(rt, spec);
		rt = ft_strjoinfree("0x", rt, 2);
	}
	else
	{
		rt = ft_strjoinfree("0x", rt, 2);
		rt = padding(rt, spec);
	}
	return (rt);
}

char			*convert_p(va_list ap, t_printf *spec)
{
	char			*rt;
	intmax_t		n;

	n = va_arg(ap, intmax_t);
	if (spec->precision == 0)
		rt = ft_strdup("");
	else
		rt = ft_itoa_base_u(n, 16);
	spec->is_plus = 0;
	if ((int)ft_strlen(rt) < spec->width ||
			(int)ft_strlen(rt) < spec->precision)
		rt = p_padding(rt, spec);
	else
	{
		if ((int)ft_strlen(rt) < (spec->width -= 2))
			rt = padding(rt, spec);
		rt = ft_strjoinfree("0x", rt, 2);
	}
	rt = ft_strmap_p(rt, ft_tolowercase);
	return (rt);
}

char			*convert_d(va_list ap, t_printf *spec)
{
	char			*rt;
	intmax_t		n;

	n = convert_len(ap, spec);
	if (!(spec->is_l || spec->is_ll || spec->is_j) && n == -2147483648)
		return (ft_strdup("-2147483648"));
	spec->negative = (n < 0) ? 1 : 0;
	n < 0 ? n = -n : 0;
	rt = ft_itoa_base(n, 10);
	if (spec->width > 0 && spec->precision > 0 && !spec->is_minus)
		spec->is_zero = 0;
	if (ft_strchr(rt, '-'))
		spec->negative = 0;
	rt = padding(rt, spec);
	if (spec->precision == 0 && n == 0)
	{
		free(rt);
		rt = (padding(ft_strdup(""), spec));
	}
	if (spec->is_zero == 1 && spec->is_space == 1 && spec->negative != 1)
		rt[0] = ' ';
	if (!spec->negative && !spec->is_plus &&
			spec->is_space && ft_atoi(rt) >= 0)
		rt = ft_strjoinfree((rt[0] != ' ') ? " " : "", rt, 2);
	return (rt);
}
