/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   padding.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/22 14:57:03 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/22 17:06:48 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static char	*handle_precision(char *s, t_printf *spec)
{
	char	*temp;
	int		dif;
	char	fil;

	if (spec->precision == 0)
		return (ft_strdup(""));
	dif = spec->precision - ft_strlen(s);
	if ((spec->is_plus || spec->negative) && spec->negative)
		spec->is_plus = 0;
	temp = ft_strnew(dif);
	fil = (spec->is_zero ||
			ft_strchr(SPECIFIERS, spec->converter)) ? '0' : ' ';
	temp = ft_memset((void*)temp, fil, dif);
	return (ft_strjoinfree(temp, s, 3));
}

static char	*handle_width(char *s, t_printf *spec)
{
	char	*temp;
	char	fil;
	int		dif;

	dif = spec->width - ft_strlen(s);
	fil = (spec->is_zero == 1 && !spec->is_minus) ? '0' : ' ';
	dif -= (spec->negative || spec->is_plus) ? 1 : 0;
	temp = ft_strnew(dif);
	temp = ft_memset((void*)temp, fil, dif);
	if (spec->is_minus)
		return (ft_strjoinfree(s, temp, 3));
	else
		return (ft_strjoinfree(temp, s, 3));
}

static char	*add_sign(char *s, t_printf *spec)
{
	char	sign;
	int		ctrl;

	ctrl = 0;
	if (spec->converter == 'c' || spec->converter == 'C')
		return (s);
	sign = (spec->negative) ? '-' : '+';
	if (spec->negative || spec->is_plus)
		s = ft_strjoinfree(" ", s, 2);
	while (s[ctrl + 1] == ' ')
		ctrl++;
	s[ctrl] = sign;
	return (s);
}

char		*padding(char *s, t_printf *spec)
{
	if (!s)
		return (NULL);
	if (spec->precision > 0 && spec->precision > (int)ft_strlen(s))
		s = handle_precision(s, spec);
	if (spec->width > 0 && spec->width > (int)ft_strlen(s))
		s = handle_width(s, spec);
	if (spec->is_plus || spec->negative)
		s = add_sign(s, spec);
	if (spec->precision > 0 && spec->width > 0 &&
			spec->width > spec->precision &&
			(int)ft_strlen(s) > spec->width && spec->is_minus)
		s[(int)ft_strlen(s) - 1] = '\0';
	return (s);
}
